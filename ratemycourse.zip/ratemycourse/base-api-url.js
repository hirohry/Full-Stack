//var BASE_API_URL = "/api/";
var BASE_API_URL = "http://10.199.13.131:8080/myproject/rest/";